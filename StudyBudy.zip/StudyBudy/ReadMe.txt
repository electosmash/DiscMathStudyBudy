Set Directory for this version to the Directory that holds
the folders "Notes", inside that you can create another 
directory that holds chapter/general notes, for each new
definition there will need to be a new folder created inside
of the chapter's/general folder. In each definition folder
there are three things it must have a text file labeled
Examples.txt,Text.txt,and a folder called Pics.Pics can
be empty.Try and make text files have as many enters as
possible as refreshing the line helps prevents errors...

In this current version pictures are not loaded...
